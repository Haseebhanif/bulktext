<x-app-layout>
    <div class="max-w-9xl mx-auto px-3 md:px-32 pt-16 w-full ">
    <main>
        <livewire:tenancy.admin-stats/>




                            <livewire:tenancy.admin-dashboard/>



    </main>
    </div>
    @push('js')

    @endpush
</x-app-layout>
