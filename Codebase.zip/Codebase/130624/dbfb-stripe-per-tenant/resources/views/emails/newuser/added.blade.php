<x-mail::message>
# NEW USER ADDED

{{ $user->email}} has been added to the {{$user->currentTeam->company->company_name}}.


</x-mail::message>
