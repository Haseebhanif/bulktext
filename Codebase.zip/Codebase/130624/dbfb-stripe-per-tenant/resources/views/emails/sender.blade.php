
    {{ __('Hello from dbfb, Please authorise the following new sender '.$sender) }}

