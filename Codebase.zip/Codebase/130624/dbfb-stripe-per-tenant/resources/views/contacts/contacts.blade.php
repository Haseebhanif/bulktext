<x-app-layout>


             <main>


            <livewire:contact.contacts/>


             </main>

    @push('js')

        @endpush

</x-app-layout>
