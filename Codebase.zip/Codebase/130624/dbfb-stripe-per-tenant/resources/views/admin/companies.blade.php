<x-app-layout>
    <main>
        <livewire:admin.company-table/>
    </main>
    @push('js')

    @endpush
</x-app-layout>
