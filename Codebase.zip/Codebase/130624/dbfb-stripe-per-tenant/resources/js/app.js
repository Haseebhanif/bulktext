import './bootstrap';

import Alpine from 'alpinejs';
window.Alpine = Alpine;

import Pikaday from 'pikaday'
window.Pikaday = Pikaday;
Alpine.start();
