<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->text('logo')->nullable();
            $table->text('background')->nullable();
            $table->text('login')->nullable();
            $table->text('register')->nullable();
            $table->string('colour1')->nullable();
            $table->string('colour2')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn('logo');
            $table->dropColumn('background');
            $table->dropColumn('login');
            $table->dropColumn('register');
            $table->dropColumn('colour1');
            $table->dropColumn('colour2');
        });
    }
};
